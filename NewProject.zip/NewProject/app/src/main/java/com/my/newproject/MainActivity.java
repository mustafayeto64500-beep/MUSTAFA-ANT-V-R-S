package com.my.newproject;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import com.my.newproject.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private MainBinding binding;
	
	private MediaPlayer mustafa3131;
	private TimerTask zaman100;
	private AlertDialog.Builder diyalog100;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		diyalog100 = new AlertDialog.Builder(this);
		
		binding.button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				zaman100 = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								diyalog100.setMessage("tarandı Tehdit Bulunamadı");
								diyalog100.create().show();
							}
						});
					}
				};
				_timer.scheduleAtFixedRate(zaman100, (int)(0), (int)(2000));
				mustafa3131 = MediaPlayer.create(getApplicationContext(), R.raw.kahretmesinogg);
				mustafa3131.setLooping(true);
				mustafa3131.start();
			}
		});
	}
	
	private void initializeLogic() {
	}
	
}